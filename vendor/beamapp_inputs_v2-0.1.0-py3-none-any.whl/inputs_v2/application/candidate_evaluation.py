"""Single candidate validation, calculation and mandatory-compliance pipeline."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from inputs_v2.application.design_brain_apply import ApplyOutcome, Candidate, apply_candidate
from inputs_v2.domain.beam_inputs import BeamInputs
from inputs_v2.domain.engineering_result import EngineeringResult


CalculateCandidate = Callable[[BeamInputs], EngineeringResult | None]


def complete_compliance(result: EngineeringResult) -> bool:
    """Return true only when every calculated mandatory check passes."""
    accepted_statuses = {
        "bending": {"PASS", "INFO"},
        "ductility": {"PASS"},
        "serviceability": {"PASS", "NOT RUN", "PROVISIONAL PASS"},
        "crack_control": {"PASS", "NOT RUN", "PROVISIONAL PASS"},
    }
    for family_name, allowed in accepted_statuses.items():
        family = result.families.get(family_name)
        if family is None or str(family.get("status", "")).upper() not in allowed:
            return False
    bending = result.families.get("bending", {})
    if str(bending.get("minimum_tensile_status", "")).upper() != "PASS":
        return False
    shear = result.families.get("shear", {})
    if shear.get("shear_ok") is not True or shear.get("web_ok") is not True:
        return False
    links_provided = float(shear.get("Asv", 0.0) or 0.0) > 0.0
    links_required = bool(shear.get("transverse_reinforcement_required"))
    if links_required and not links_provided:
        return False
    if links_provided and shear.get("min_shear_ok") is not True:
        return False
    if links_provided and shear.get("spacing_ok") is not True:
        return False
    return bool(result.families.get("reinforcement_fit", {}).get("accepted", False))


@dataclass(frozen=True, slots=True)
class CandidateEvaluation:
    candidate: Candidate
    outcome: ApplyOutcome
    result: EngineeringResult | None
    mandatory_compliance: bool

    @property
    def usable(self) -> bool:
        return self.outcome.applied and self.result is not None and self.mandatory_compliance


def evaluate_candidate(
    current: BeamInputs,
    candidate: Candidate,
    calculate: CalculateCandidate,
) -> CandidateEvaluation:
    """Run the canonical pipeline; family rules may only rank usable results."""
    outcome = apply_candidate(current, candidate)
    if not outcome.applied:
        return CandidateEvaluation(candidate, outcome, None, False)
    result = calculate(outcome.inputs)
    return CandidateEvaluation(
        candidate,
        outcome,
        result,
        result is not None and complete_compliance(result),
    )
