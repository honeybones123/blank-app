"""Calculator-backed bending overdesign cleanup pipeline."""

from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Any, Callable

from inputs_v2.application.candidate_evaluation import complete_compliance
from inputs_v2.application.design_brain.bending_overdesign_policy import (
    generate_overdesign_geometry_cells,
    generate_reinforcement_reductions,
    generate_shear_preservation_options,
)
from inputs_v2.application.design_brain.bending_overdesign_selection import (
    Trial,
    select_bending_overdesign_preview,
)
from inputs_v2.application.design_brain.preview import DesignBrainPreview
from inputs_v2.application.design_brain_apply import (
    Candidate,
    propose_fixture_bottom_reinforcement,
)
from inputs_v2.domain.beam_inputs import BeamInputs
from inputs_v2.domain.engineering_result import EngineeringResult


Calculate = Callable[[BeamInputs], EngineeringResult]
Evaluate = Callable[..., Any]
RankKey = Callable[[BeamInputs, Candidate, EngineeringResult, float, float], tuple]


@dataclass(frozen=True)
class BendingOverdesignOutcome:
    preview: DesignBrainPreview
    metrics: dict[str, float | int | bool]


class BendingOverdesignPipeline:
    """Evaluate geometry, reinforcement and shear-preservation cleanup stages."""

    def __init__(
        self,
        *,
        calculate: Calculate,
        evaluate: Evaluate,
        rank_key: RankKey,
    ) -> None:
        self._calculate = calculate
        self._evaluate = evaluate
        self._rank_key = rank_key

    def preview(self, current: BeamInputs) -> BendingOverdesignOutcome:
        before = self._calculate(current)
        current_util = float(
            before.families.get("bending", {}).get("util", 0.0) or 0.0
        )
        seed = propose_fixture_bottom_reinforcement(current)
        trials: list[Trial] = []
        reinforcement_trials: list[Trial] = []
        shear_preservation_queue: list[
            tuple[float, Candidate, EngineeringResult]
        ] = []
        metrics: dict[str, float | int | bool] = {
            "proportion_triggered": False,
            "additional_evaluations": 0,
            "geometry_evaluations": 0,
            "reinforcement_evaluations": 0,
        }
        geometry_attempted = False
        minimum_reinforcement_blocked = False
        ductility_blocked = False

        for cell in generate_overdesign_geometry_cells(current, current_util):
            metrics["geometry_evaluations"] = int(
                metrics["geometry_evaluations"]
            ) + 1
            geometry_attempted = True
            for bars, diameter in cell.arrangements:
                proposal = replace(
                    seed.proposal,
                    width_mm=cell.width_mm,
                    depth_mm=cell.depth_mm,
                    bottom_bars=bars,
                    bottom_diameter_mm=diameter,
                )
                candidate = Candidate(
                    f"bending-overdesign-geometry-{int(cell.width_mm)}-{int(cell.depth_mm)}-{bars}-N{diameter}",
                    current.revision,
                    current.content_hash,
                    proposal,
                    "Test a smaller, rebalanced section while retaining every governing check.",
                )
                evaluation = self._evaluate(current, candidate)
                metrics["additional_evaluations"] = int(
                    metrics["additional_evaluations"]
                ) + 1
                result = evaluation.result
                if result is not None:
                    bending = result.families.get("bending", {})
                    minimum_reinforcement_blocked |= (
                        str(bending.get("minimum_tensile_status", "PASS")).upper()
                        == "FAIL"
                    )
                    ductility_blocked |= (
                        str(
                            result.families.get("ductility", {}).get(
                                "status", "PASS"
                            )
                        ).upper()
                        == "FAIL"
                    )
                    trial_util = float(bending.get("util", 0.0) or 0.0)
                    if (
                        not evaluation.usable
                        and current.actions.shear_force_kn > 0.0
                        and current_util < trial_util <= 1.0
                    ):
                        shear_preservation_queue.append(
                            (abs(trial_util - 0.925), candidate, result)
                        )
                if not evaluation.usable or result is None:
                    continue
                util = float(
                    result.families.get("bending", {}).get("util", 0.0) or 0.0
                )
                if util <= 1.0 and complete_compliance(result):
                    area_ratio = cell.width_mm * cell.depth_mm / max(
                        current.width_mm * current.depth_mm, 1.0
                    )
                    edit_size = (
                        abs(cell.width_mm - current.width_mm) / 100
                        + abs(cell.depth_mm - current.depth_mm) / 100
                        + abs(bars - current.bottom.bars)
                        + abs(diameter - current.bottom.diameter_mm) / 10
                    )
                    trials.append(
                        (
                            area_ratio + abs(util - 0.925) * 0.05,
                            candidate,
                            result,
                            edit_size,
                        )
                    )

        for reduction in generate_reinforcement_reductions(current):
            candidate = Candidate(
                f"bending-overdesign-{reduction.bars}-N{reduction.diameter_mm}",
                current.revision,
                current.content_hash,
                replace(
                    seed.proposal,
                    bottom_bars=reduction.bars,
                    bottom_diameter_mm=reduction.diameter_mm,
                ),
                "Bending overdesign cleanup: reduce bottom reinforcement while preserving compliance.",
            )
            evaluation = self._evaluate(current, candidate)
            metrics["reinforcement_evaluations"] = int(
                metrics["reinforcement_evaluations"]
            ) + 1
            metrics["additional_evaluations"] = int(
                metrics["additional_evaluations"]
            ) + 1
            result = evaluation.result
            if result is not None:
                bending = result.families.get("bending", {})
                util = float(bending.get("util", 0.0) or 0.0)
                if (
                    not evaluation.usable
                    and current.actions.shear_force_kn > 0.0
                    and current_util < util <= 1.0
                ):
                    shear_preservation_queue.append(
                        (abs(util - 0.925), candidate, result)
                    )
            if not evaluation.usable or result is None:
                continue
            bending = result.families.get("bending", {})
            minimum_reinforcement_blocked |= (
                str(bending.get("minimum_tensile_status", "PASS")).upper()
                == "FAIL"
            )
            ductility_blocked |= (
                str(
                    result.families.get("ductility", {}).get("status", "PASS")
                ).upper()
                == "FAIL"
            )
            util = float(bending.get("util", 0.0) or 0.0)
            if util <= 1.0 and complete_compliance(result):
                row = (
                    abs(util - 0.925),
                    candidate,
                    result,
                    abs(reduction.bars - current.bottom.bars)
                    + abs(reduction.diameter_mm - current.bottom.diameter_mm) / 10,
                )
                reinforcement_trials.append(row)
                trials.append(row)

        self._append_shear_preservation_trials(
            current, current_util, shear_preservation_queue, trials
        )
        preview = select_bending_overdesign_preview(
            current=current,
            before=before,
            seed=seed,
            trials=trials,
            reinforcement_trials=reinforcement_trials,
            geometry_attempted=geometry_attempted,
            minimum_reinforcement_blocked=minimum_reinforcement_blocked,
            ductility_blocked=ductility_blocked,
            rank_key=self._rank_key,
        )
        return BendingOverdesignOutcome(preview, metrics)

    def _append_shear_preservation_trials(
        self,
        current: BeamInputs,
        current_util: float,
        queue: list[tuple[float, Candidate, EngineeringResult]],
        trials: list[Trial],
    ) -> None:
        for _distance, base_candidate, _base_result in sorted(
            queue, key=lambda row: row[0]
        )[:16]:
            for option in generate_shear_preservation_options(current):
                candidate = replace(
                    base_candidate,
                    candidate_id=(
                        f"{base_candidate.candidate_id}-preserve-shear-"
                        f"{option.diameter_mm}-{option.legs}-{int(option.spacing_mm)}"
                    ),
                    proposal=replace(
                        base_candidate.proposal,
                        shear_diameter_mm=option.diameter_mm,
                        shear_legs=option.legs,
                        shear_spacing_mm=option.spacing_mm,
                    ),
                    rationale=(
                        "Optimise bending while preserving the governing shear resistance."
                    ),
                )
                evaluation = self._evaluate(current, candidate)
                result = evaluation.result
                if not evaluation.usable or result is None:
                    continue
                util = float(
                    result.families.get("bending", {}).get("util", 0.0) or 0.0
                )
                if not current_util < util <= 1.0:
                    continue
                area_ratio = (
                    candidate.proposal.width_mm * candidate.proposal.depth_mm
                    / max(current.width_mm * current.depth_mm, 1.0)
                )
                edit_size = (
                    abs(candidate.proposal.width_mm - current.width_mm) / 100
                    + abs(candidate.proposal.depth_mm - current.depth_mm) / 100
                    + abs(candidate.proposal.bottom_bars - current.bottom.bars)
                    + abs(
                        candidate.proposal.bottom_diameter_mm
                        - current.bottom.diameter_mm
                    )
                    / 10
                    + abs(option.diameter_mm - current.shear.diameter_mm) / 10
                    + abs(option.legs - current.shear.legs)
                    + abs(option.spacing_mm - current.shear.spacing_mm) / 100
                )
                trials.append(
                    (
                        area_ratio + abs(util - 0.925) * 0.05,
                        candidate,
                        result,
                        edit_size,
                    )
                )
                break


__all__ = ["BendingOverdesignOutcome", "BendingOverdesignPipeline"]
