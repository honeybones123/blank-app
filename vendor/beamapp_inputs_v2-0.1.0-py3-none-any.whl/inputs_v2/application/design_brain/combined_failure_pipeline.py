"""Atomic bending-and-shear failure repair pipeline."""

from __future__ import annotations

from dataclasses import replace
from typing import Any, Callable

from inputs_v2.application.candidate_evaluation import complete_compliance
from inputs_v2.application.design_brain.preview import DesignBrainPreview
from inputs_v2.application.design_brain.ratio_policy import ratio_gate_required
from inputs_v2.application.design_brain_apply import Candidate, propose_fixture_bottom_reinforcement
from inputs_v2.domain.beam_inputs import BeamInputs
from inputs_v2.domain.engineering_result import EngineeringResult


Calculate = Callable[[BeamInputs], EngineeringResult]
Evaluate = Callable[..., Any]
RankKey = Callable[[BeamInputs, Candidate, EngineeringResult, float, float], tuple]


class CombinedFailurePipeline:
    """Evaluate one atomic candidate that repairs both governing failures."""

    def __init__(self, *, calculate: Calculate, evaluate: Evaluate, rank_key: RankKey) -> None:
        self._calculate = calculate
        self._evaluate = evaluate
        self._rank_key = rank_key

    def preview(self, current: BeamInputs) -> DesignBrainPreview:
        before = self._calculate(current)
        bending_before = float(before.families.get("bending", {}).get("util", 0.0) or 0.0)
        seed = propose_fixture_bottom_reinforcement(current)
        trials: list[tuple[float, Candidate, EngineeringResult, float]] = []
        widths = (
            (float(current.width_mm),)
            if current.width_locked
            else (
                float(current.width_mm),
                *(current.width_mm + 25.0 * index for index in range(1, 5)),
            )
        )
        current_ast = current.bottom.bars * 0.7854 * current.bottom.diameter_mm**2
        for width in widths:
            max_depth = min(5000.0, 2.0 * width)
            depths = (
                (float(current.depth_mm),)
                if current.depth_locked
                else (
                    float(current.depth_mm),
                    *(depth for depth in range(int(current.depth_mm) + 50, int(max_depth) + 1, 50)),
                )
            )
            for depth in depths:
                required_ast = current_ast * max(bending_before, 1.0) / 0.925 * current.depth_mm / max(depth, 1.0)
                bottom_pool = sorted(
                    (
                        (bars * 0.7854 * diameter**2, bars, diameter)
                        for bars in range(max(2, current.bottom.bars), 13)
                        for diameter in (10, 12, 16, 20, 24, 28, 32, 36, 40)
                    ),
                    key=lambda row: (0 if row[0] >= required_ast else 1, abs(row[0] - required_ast), row[1], row[2]),
                )[:12]
                links = sorted(
                    (
                        (diameter, legs, spacing, legs * diameter**2 / spacing)
                        for diameter in (10, 12, 16)
                        for legs in (2, 4, 6, 8)
                        for spacing in (300.0, 250.0, 200.0, 175.0, 150.0, 125.0, 100.0)
                    ),
                    key=lambda row: (row[3], row[0], row[1], -row[2]),
                )
                for _area, bars, diameter in bottom_pool:
                    for shear_diameter, legs, spacing, _index in links:
                        candidate = Candidate(
                            f"combined-failure-{bars}-N{diameter}-{shear_diameter}-{legs}-{int(spacing)}",
                            current.revision,
                            current.content_hash,
                            replace(
                                seed.proposal,
                                width_mm=width,
                                depth_mm=depth,
                                bottom_bars=bars,
                                bottom_diameter_mm=diameter,
                                shear_diameter_mm=shear_diameter,
                                shear_legs=legs,
                                shear_spacing_mm=spacing,
                            ),
                            "Combined bending/shear ladder: atomically repair both governing failures.",
                        )
                        evaluation = self._evaluate(current, candidate)
                        if not evaluation.usable:
                            continue
                        result = evaluation.result
                        assert result is not None
                        bend = float(result.families.get("bending", {}).get("util", 0.0) or 0.0)
                        capacity = float(result.families.get("shear", {}).get("phi_Vu", 0.0) or 0.0)
                        shear = abs(float(evaluation.outcome.inputs.actions.shear_force_kn)) / capacity if capacity > 0 else 0.0
                        target = max(bend, shear)
                        in_band = 0.85 <= bend <= 1.0 and 0.85 <= shear <= 1.0
                        distance = abs(target - 0.925) + (0.0 if in_band else 10.0)
                        edit_size = (
                            abs(width - current.width_mm) / 100
                            + abs(depth - current.depth_mm) / 100
                            + abs(bars - current.bottom.bars)
                            + abs(diameter - current.bottom.diameter_mm) / 10
                            + abs(shear_diameter - current.shear.diameter_mm) / 10
                            + abs(legs - current.shear.legs) / 2
                            + abs(spacing - current.shear.spacing_mm) / 100
                        )
                        trials.append((distance, candidate, result, edit_size))
                        if in_band:
                            return DesignBrainPreview(candidate, before, result, ("bottom", "shear"), True, "combined_target_band_candidate", 0.85, 1.0)
        if not trials:
            return DesignBrainPreview(seed, before, before, (), False, "no_valid_combined_repair", 0.85, 1.0)
        _, candidate, after, _ = min(
            trials,
            key=lambda row: self._rank_key(current, row[1], row[2], row[0], row[3]),
        )
        bend = float(after.families.get("bending", {}).get("util", 0.0) or 0.0)
        capacity = float(after.families.get("shear", {}).get("phi_Vu", 0.0) or 0.0)
        shear = abs(float(current.actions.shear_force_kn)) / capacity if capacity > 0 else 0.0
        # Failure repair and efficiency optimisation are separate decisions.
        # Every trial retained above is already fully compliant.  Prefer an
        # in-band result when the discrete candidate space contains one, but
        # do not block a safe repair merely because one repaired utilisation
        # falls below the optimisation band.  The next Design Brain run can
        # optimise that compliant design as a separate recommendation.
        accepted = (
            bend <= 1.0
            and shear <= 1.0
            and complete_compliance(after)
            and not ratio_gate_required(current, candidate.proposal, after)
        )
        if accepted:
            reason = (
                "combined_target_band_candidate"
                if 0.85 <= bend <= 1.0 and 0.85 <= shear <= 1.0
                else "safe_combined_failure_repair"
            )
        else:
            reason = "no_combined_target_band_candidate"
        return DesignBrainPreview(candidate, before, after, ("bottom", "shear"), accepted, reason, 0.85, 1.0)


__all__ = ["CombinedFailurePipeline"]
