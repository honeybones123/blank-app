"""Atomic material and geometry cleanup for combined overdesign."""

from __future__ import annotations

from dataclasses import replace
from typing import Any, Callable

from inputs_v2.application.candidate_evaluation import complete_compliance
from inputs_v2.application.design_brain.preview import DesignBrainPreview
from inputs_v2.application.design_brain.ratio_policy import ratio_gate_required
from inputs_v2.application.design_brain_apply import (
    Candidate,
    propose_fixture_bottom_reinforcement,
)
from inputs_v2.domain.beam_inputs import BeamInputs
from inputs_v2.domain.engineering_result import EngineeringResult


Calculate = Callable[[BeamInputs], EngineeringResult]
Evaluate = Callable[..., Any]
RankKey = Callable[[BeamInputs, Candidate, EngineeringResult, float, float], tuple]


class CombinedOverdesignPipeline:
    """Select one reviewable combined cleanup from recalculated candidates."""

    def __init__(self, *, calculate: Calculate, evaluate: Evaluate, rank_key: RankKey) -> None:
        self._calculate = calculate
        self._evaluate = evaluate
        self._rank_key = rank_key

    def preview(self, current: BeamInputs) -> DesignBrainPreview:
        before = self._calculate(current)
        seed = propose_fixture_bottom_reinforcement(current)
        trials = []
        widths = (
            (current.width_mm,)
            if current.width_locked
            else tuple(float(width) for width in range(int(current.width_mm), 149, -25))
        )
        depths = (
            (current.depth_mm,)
            if current.depth_locked
            else tuple(float(depth) for depth in range(int(current.depth_mm), 149, -25))
        )
        for width in widths:
            for depth in depths:
                if depth > 2.0 * width:
                    continue
                for bars in range(2, current.bottom.bars + 1):
                    for diameter in (10, 12, 16, 20, 24, 28, 32):
                        if diameter > current.bottom.diameter_mm:
                            continue
                        for spacing in (200.0, 250.0, 300.0, 400.0, 500.0, 600.0):
                            proposal = replace(
                                seed.proposal,
                                width_mm=width,
                                depth_mm=depth,
                                bottom_bars=bars,
                                bottom_diameter_mm=diameter,
                                shear_spacing_mm=spacing,
                                shear_diameter_mm=current.shear.diameter_mm,
                                shear_legs=current.shear.legs,
                            )
                            candidate = Candidate(
                                f"combined-overdesign-{int(width)}-{int(depth)}-{bars}-N{diameter}-{int(spacing)}",
                                current.revision,
                                current.content_hash,
                                proposal,
                                "Combined overdesign cleanup: reduce reinforcement and geometry atomically.",
                            )
                            evaluation = self._evaluate(current, candidate)
                            if not evaluation.usable:
                                continue
                            result = evaluation.result
                            assert result is not None
                            if complete_compliance(result):
                                edit = (
                                    abs(width - current.width_mm) / 100
                                    + abs(depth - current.depth_mm) / 100
                                    + abs(bars - current.bottom.bars)
                                    + abs(spacing - current.shear.spacing_mm) / 100
                                )
                                trials.append((edit, candidate, result, edit))
        if not trials:
            if (
                abs(float(current.actions.bending_moment_knm)) < 1e-9
                and abs(float(current.actions.shear_force_kn)) < 1e-9
            ):
                return DesignBrainPreview(seed, before, before, (), False, "no_safe_combined_cleanup", 0.85, 1.0)
            width_trials = (
                (current.width_mm - 25.0, current.width_mm - 50.0)
                if not current.width_locked
                else (current.width_mm,)
            )
            depth_trials = (
                (current.depth_mm - 25.0, current.depth_mm - 50.0)
                if not current.depth_locked
                else (current.depth_mm,)
            )
            for width in width_trials:
                for depth in depth_trials:
                    if width < 150.0 or depth < 200.0 or depth > 2.0 * width:
                        continue
                    proposal = replace(
                        seed.proposal,
                        width_mm=width,
                        depth_mm=depth,
                        bottom_bars=current.bottom.bars,
                        bottom_diameter_mm=current.bottom.diameter_mm,
                        shear_diameter_mm=current.shear.diameter_mm,
                        shear_legs=current.shear.legs,
                        shear_spacing_mm=current.shear.spacing_mm,
                    )
                    candidate = Candidate(
                        f"combined-geometry-{int(width)}-{int(depth)}",
                        current.revision,
                        current.content_hash,
                        proposal,
                        "Reduce geometry while retaining the verified reinforcement arrangement.",
                    )
                    evaluation = self._evaluate(current, candidate)
                    if not evaluation.usable:
                        continue
                    result = evaluation.result
                    assert result is not None
                    bending_utilisation = float(
                        result.families.get("bending", {}).get("util", 0.0) or 0.0
                    )
                    if bending_utilisation <= 1.0:
                        edit = (
                            abs(width - current.width_mm) / 100
                            + abs(depth - current.depth_mm) / 100
                        )
                        trials.append((abs(bending_utilisation - 0.925), candidate, result, edit))
            if not trials:
                return DesignBrainPreview(seed, before, before, (), False, "no_safe_combined_cleanup", 0.85, 1.0)
        _, candidate, after, _ = min(
            trials,
            key=lambda row: self._rank_key(current, row[1], row[2], row[0], row[3]),
        )
        changed = tuple(
            field
            for field, old, new in (
                ("width_mm", current.width_mm, candidate.proposal.width_mm),
                ("depth_mm", current.depth_mm, candidate.proposal.depth_mm),
                ("bottom.bars", current.bottom.bars, candidate.proposal.bottom_bars),
                ("bottom.diameter_mm", current.bottom.diameter_mm, candidate.proposal.bottom_diameter_mm),
                ("shear.spacing_mm", current.shear.spacing_mm, candidate.proposal.shear_spacing_mm),
            )
            if old != new
        )
        active_utilisations: list[float] = []
        if abs(float(current.actions.bending_moment_knm)) > 1e-9:
            active_utilisations.append(
                float(after.families.get("bending", {}).get("util", 0.0) or 0.0)
            )
        if abs(float(current.actions.shear_force_kn)) > 1e-9:
            shear_family = after.families.get("shear", {})
            capacity = float(shear_family.get("phi_Vu", 0.0) or 0.0)
            active_utilisations.append(
                abs(float(current.actions.shear_force_kn)) / capacity
                if capacity > 0.0
                else float("inf")
            )
        accepted = (
            bool(active_utilisations)
            and all(0.85 <= utilisation <= 1.0 for utilisation in active_utilisations)
            and complete_compliance(after)
            and not ratio_gate_required(current, candidate.proposal, after)
        )
        reason = (
            "combined_overdesign_cleanup"
            if accepted
            else "no_improving_combined_cleanup"
        )
        return DesignBrainPreview(
            candidate,
            before,
            after,
            changed,
            accepted,
            reason,
            0.85,
            1.0,
        )


__all__ = ["CombinedOverdesignPipeline"]
