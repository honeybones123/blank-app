"""Calculator-backed shear failure repair pipeline."""

from __future__ import annotations

from dataclasses import replace
from typing import Any, Callable

from inputs_v2.application.candidate_evaluation import complete_compliance
from inputs_v2.application.design_brain.preview import DesignBrainPreview
from inputs_v2.application.design_brain.shear_repair_policy import generate_shear_repair_specs
from inputs_v2.application.design_brain_apply import Candidate, propose_fixture_bottom_reinforcement
from inputs_v2.domain.beam_inputs import BeamInputs
from inputs_v2.domain.engineering_result import EngineeringResult

Calculate = Callable[[BeamInputs], EngineeringResult]
Evaluate = Callable[..., Any]
RankKey = Callable[[BeamInputs, Candidate, EngineeringResult, float, float], tuple]


class ShearFailurePipeline:
    """Evaluate the declared shear ladder and select one verified repair."""

    def __init__(self, *, calculate: Calculate, evaluate: Evaluate, rank_key: RankKey) -> None:
        self._calculate = calculate
        self._evaluate = evaluate
        self._rank_key = rank_key

    def preview(self, current: BeamInputs) -> DesignBrainPreview:
        before = self._calculate(current)
        capacity = float(before.families.get("shear", {}).get("phi_Vu", 0.0))
        current_util = abs(float(current.actions.shear_force_kn)) / capacity if capacity > 0 else 0.0
        seed = propose_fixture_bottom_reinforcement(current)
        if current_util <= 1.0:
            return DesignBrainPreview(seed, before, before, (), False, "shear_not_failed")
        low, high = 0.85, 1.0
        trials: list[tuple[float, Candidate, BeamInputs, EngineeringResult, float]] = []
        for lane, changes, edit_size in generate_shear_repair_specs(current, current_util):
            candidate = Candidate(
                f"shear-only-{lane}-{len(trials)}",
                current.revision,
                current.content_hash,
                replace(seed.proposal, **changes),
                f"Shear-only ladder: {lane} repair toward 0.85–1.00 utilisation.",
            )
            evaluation = self._evaluate(current, candidate)
            if not evaluation.usable:
                continue
            result = evaluation.result
            assert result is not None
            capacity = float(result.families.get("shear", {}).get("phi_Vu", 0.0))
            util = abs(float(evaluation.outcome.inputs.actions.shear_force_kn)) / capacity if capacity > 0 else 0.0
            in_band = low <= util <= high
            distance = 0.0 if in_band else abs(util - (low + high) / 2.0)
            trials.append((distance + (0.0 if in_band else 10.0), candidate, evaluation.outcome.inputs, result, edit_size))
            if in_band:
                return DesignBrainPreview(candidate, before, result, ("shear",), True, "shear_target_band_candidate", low, high)
        if not trials:
            return DesignBrainPreview(seed, before, before, (), False, "no_valid_shear_repair", low, high)
        _, candidate, _, after, _ = min(
            trials,
            key=lambda row: self._rank_key(current, row[1], row[3], row[0], row[4]),
        )
        capacity = float(after.families.get("shear", {}).get("phi_Vu", 0.0))
        util = abs(float(current.actions.shear_force_kn)) / capacity if capacity > 0 else 0.0
        compliant = complete_compliance(after)
        accepted = util <= high and compliant
        reason = (
            "shear_target_band_candidate"
            if accepted and util >= low
            else "safe_shear_failure_repair"
            if accepted
            else "no_improving_shear_target_band_candidate"
        )
        return DesignBrainPreview(candidate, before, after, ("shear",), accepted, reason, low, high)


__all__ = ["ShearFailurePipeline"]
