"""Longitudinal reinforcement-ratio review policy for candidate acceptance."""

from __future__ import annotations

from inputs_v2.domain.beam_inputs import BeamInputs
from inputs_v2.domain.engineering_result import EngineeringResult
from inputs_v2.engineering.reinforcement_policy import ratio_trigger, tension_ratio


def ratio_review_required(inputs: BeamInputs, result: EngineeringResult) -> bool:
    """Return true when longitudinal steel is below the policy review floor."""
    bending = result.families.get("bending", {})
    ast = float(bending.get("Ast_bot", bending.get("Ast_tension_mm2", 0.0)) or 0.0)
    cover = float(getattr(getattr(inputs, "bottom", None), "cover_mm", 40.0) or 40.0)
    effective_depth = float(
        bending.get("effective_depth_mm", max(float(inputs.depth_mm) - cover, 1.0))
        or 1.0
    )
    return ratio_trigger(
        tension_ratio(ast, float(inputs.width_mm), effective_depth)
    ) is not None


def ratio_gate_required(
    current: BeamInputs,
    proposal: BeamInputs,
    result: EngineeringResult,
) -> bool:
    """Gate strong low-ratio outcomes unless enlarged geometry justifies them."""
    if not ratio_review_required(proposal, result):
        return False
    enlarged = (
        float(proposal.width_mm) > float(current.width_mm) * 1.20
        or float(proposal.depth_mm) > float(current.depth_mm) * 1.20
    )
    bending = result.families.get("bending", {})
    ast = float(bending.get("Ast_bot", bending.get("Ast_tension_mm2", 0.0)) or 0.0)
    effective_depth = float(
        bending.get(
            "effective_depth_mm",
            max(float(proposal.depth_mm) - 40.0, 1.0),
        )
        or 1.0
    )
    ratio = tension_ratio(ast, float(proposal.width_mm), effective_depth)
    return ratio < 0.003 and not enlarged


__all__ = ["ratio_gate_required", "ratio_review_required"]
