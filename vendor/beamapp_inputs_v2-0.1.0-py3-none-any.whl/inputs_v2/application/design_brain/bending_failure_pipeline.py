"""Calculator-backed primary bending repair pipeline."""

from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Any, Callable

from inputs_v2.application.candidate_evaluation import complete_compliance
from inputs_v2.application.design_brain.bending_proportion_pipeline import BendingProportionPipeline
from inputs_v2.application.design_brain.bending_repair_policy import (
    generate_bending_reduction_specs,
    generate_bending_width_lanes,
)
from inputs_v2.application.design_brain.candidate_ranking import bending_candidate_rank_key
from inputs_v2.application.design_brain.preview import DesignBrainPreview
from inputs_v2.application.design_brain.ratio_policy import ratio_gate_required
from inputs_v2.application.design_brain_apply import Candidate, propose_fixture_bottom_reinforcement
from inputs_v2.domain.beam_inputs import BeamInputs
from inputs_v2.domain.engineering_result import EngineeringResult


Calculate = Callable[[BeamInputs], EngineeringResult]
Evaluate = Callable[..., Any]


@dataclass(frozen=True)
class BendingFailureOutcome:
    preview: DesignBrainPreview
    metrics: dict[str, float | int | bool | tuple[str, ...]] | None = None


class BendingFailurePipeline:
    """Evaluate, balance and verify the primary bending repair ladder."""

    def __init__(self, *, calculate: Calculate, evaluate: Evaluate) -> None:
        self._calculate = calculate
        self._evaluate = evaluate

    def preview(self, current: BeamInputs) -> BendingFailureOutcome:
        before = self._calculate(current)
        current_util = float(before.families.get("bending", {}).get("util", 0.0))
        seed = propose_fixture_bottom_reinforcement(current)
        if current_util <= 0.0:
            return BendingFailureOutcome(
                DesignBrainPreview(seed, before, before, (), False, "no_bending_demand")
            )
        low, high = 0.85, 1.0
        midpoint = (low + high) / 2.0
        trials: list[tuple[float, Candidate, BeamInputs, EngineeringResult, float]] = []
        for width_lane in generate_bending_width_lanes(current, current_util, low):
            current_width_has_target = False
            for spec in width_lane.candidates:
                candidate = Candidate(
                    f"bending-only-b{int(spec.width_mm)}-{int(spec.depth_mm)}-{spec.bars}-N{spec.diameter_mm}-rows{'-'.join(map(str, spec.row_counts))}",
                    current.revision,
                    current.content_hash,
                    replace(
                        seed.proposal,
                        depth_mm=spec.depth_mm,
                        bottom_bars=spec.bars,
                        bottom_diameter_mm=spec.diameter_mm,
                        width_mm=spec.width_mm,
                    ),
                    f"Bending ladder: select {spec.bars}-N{spec.diameter_mm} at {spec.depth_mm:.0f} mm depth and {spec.width_mm:.0f} mm width.",
                    spec.row_counts,
                )
                evaluation = self._evaluate(current, candidate, provisional=True)
                if not evaluation.usable:
                    continue
                result = evaluation.result
                assert result is not None
                util = float(result.families.get("bending", {}).get("util", 0.0))
                in_band = low <= util <= high
                distance = 0.0 if in_band else abs(util - midpoint)
                congestion = result.families.get("reinforcement_fit", {}).get("congestion_class", "low")
                congestion_penalty = {"low": 0.0, "moderate": 0.25, "high": 0.75, "invalid": 10.0}.get(congestion, 1.0)
                edit_size = (
                    abs(spec.bars - current.bottom.bars)
                    + abs(spec.diameter_mm - current.bottom.diameter_mm) / 10.0
                    + abs(spec.depth_mm - current.depth_mm) / 100.0
                    + abs(spec.width_mm - current.width_mm) / 100.0
                    + (len(spec.row_counts) - 1) * 0.25
                    + congestion_penalty
                )
                trials.append((distance + (0.0 if in_band else 10.0), candidate, evaluation.outcome.inputs, result, edit_size))
                if in_band and spec.width_mm == float(current.width_mm):
                    current_width_has_target = True
            if width_lane.width_mm == float(current.width_mm) and current_width_has_target:
                break
        if not trials:
            return BendingFailureOutcome(
                DesignBrainPreview(seed, before, before, (), False, "no_valid_bending_candidate", low, high)
            )

        def rank(row):
            return bending_candidate_rank_key(current, row[1], row[3], row[0], row[4])

        if current_util < low:
            direct_reductions = []
            for spec in generate_bending_reduction_specs(current):
                trial = Candidate(
                    f"direct-cleanup-{int(spec.width_mm)}-{int(spec.depth_mm)}-{spec.bars}-N{spec.diameter_mm}",
                    current.revision,
                    current.content_hash,
                    replace(seed.proposal, width_mm=spec.width_mm, depth_mm=spec.depth_mm, bottom_bars=spec.bars, bottom_diameter_mm=spec.diameter_mm),
                    "Verified geometry reduction with minimum reinforcement retained.",
                    spec.row_counts,
                )
                evaluation = self._evaluate(current, trial, provisional=True)
                if evaluation.usable:
                    assert evaluation.result is not None
                    direct_reductions.append((spec.width_mm * spec.depth_mm, trial, evaluation.outcome.inputs, evaluation.result, abs(spec.bars - current.bottom.bars)))
            if direct_reductions:
                _, candidate, updated_inputs, after, _ = min(direct_reductions, key=lambda row: (row[0], row[4]))
            else:
                reductions = [
                    row for row in trials
                    if row[2].width_mm * row[2].depth_mm < current.width_mm * current.depth_mm
                    and complete_compliance(row[3])
                ]
                _, candidate, updated_inputs, after, _ = min(
                    reductions if reductions else trials,
                    key=(
                        (lambda row: (row[2].width_mm * row[2].depth_mm, row[4]))
                        if reductions else rank
                    ),
                )
        else:
            _, candidate, updated_inputs, after, _ = min(trials, key=rank)
        after_util = float(after.families.get("bending", {}).get("util", 0.0))
        if not (low <= after_util <= high) or abs(after_util - midpoint) >= abs(current_util - midpoint):
            return BendingFailureOutcome(
                DesignBrainPreview(candidate, before, after, ("bottom.bars",), False, "no_improving_target_band_candidate", low, high)
            )

        initial = candidate, updated_inputs, after
        balance = BendingProportionPipeline(evaluate=self._evaluate).balance(
            current, before, candidate, updated_inputs, after
        )
        candidate, updated_inputs, after, reason = (
            balance.candidate,
            balance.updated_inputs,
            balance.result,
            balance.reason,
        )
        actual_after = self._calculate(updated_inputs)
        if low <= float(actual_after.families.get("bending", {}).get("util", 0.0) or 0.0) <= high:
            after = actual_after
        elif reason == "proportion_balanced_candidate":
            candidate, updated_inputs, after = initial
            reason = "target_band_candidate"
        changed = tuple(
            field
            for field, old, new in (
                ("width_mm", current.width_mm, candidate.proposal.width_mm),
                ("depth_mm", current.depth_mm, candidate.proposal.depth_mm),
                ("bottom.bars", current.bottom.bars, candidate.proposal.bottom_bars),
                ("bottom.diameter_mm", current.bottom.diameter_mm, candidate.proposal.bottom_diameter_mm),
            )
            if old != new
        )
        final_util = float(after.families.get("bending", {}).get("util", 0.0) or 0.0)
        ratio_blocked = ratio_gate_required(current, candidate.proposal, after)
        unnecessary_layer = (
            len(candidate.row_counts)
            > int(current.bottom_arrangement.layer_count if current.bottom_arrangement is not None else 1)
            and candidate.proposal.width_mm >= current.width_mm
            and candidate.proposal.depth_mm >= current.depth_mm
            and final_util <= 1.0
        )
        geometry_reduced = candidate.proposal.width_mm * candidate.proposal.depth_mm < current.width_mm * current.depth_mm
        safe_cleanup = geometry_reduced and complete_compliance(after) and final_util <= 1.0 and not ratio_blocked
        if (
            final_util < low
            and candidate.proposal.width_mm < current.width_mm
            and candidate.proposal.depth_mm < current.depth_mm
            and complete_compliance(after)
            and not ratio_blocked
        ):
            safe_cleanup = True
        verified = (low <= final_util <= high and not ratio_blocked and not unnecessary_layer) or safe_cleanup
        if ratio_blocked:
            final_reason = "ratio_proportion_review_required"
        elif unnecessary_layer:
            final_reason = "unnecessary_additional_reinforcement_layer"
        elif safe_cleanup and not (low <= final_util <= high):
            final_reason = "safe_overdesign_cleanup"
        else:
            final_reason = reason if verified else "no_improving_target_band_candidate"
        return BendingFailureOutcome(
            DesignBrainPreview(candidate, before, after, changed, verified, final_reason, low, high),
            balance.metrics,
        )


__all__ = ["BendingFailureOutcome", "BendingFailurePipeline"]
