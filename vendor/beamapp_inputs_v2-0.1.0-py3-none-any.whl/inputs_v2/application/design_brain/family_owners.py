"""Explicit owners for every non-terminal Design Brain family contract.

Each owner binds one family contract to one typed ladder entry point.  The
owners may reuse the common search engine, but neither the orchestrator nor
presentation can select a concrete ladder or reach into its implementation.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from typing import Callable

from inputs_v2.application.design_brain_families import DesignFamily, ENTRY_CONDITIONS, EntryCondition
from inputs_v2.application.design_brain_service import DesignBrainPreview, DesignBrainService
from inputs_v2.application.ranking_policy import CandidateEvidence
from inputs_v2.application.design_brain.text_contracts import FAMILY_TEXT_CONTRACTS
from inputs_v2.domain.beam_inputs import BeamInputs
from inputs_v2.domain.engineering_result import EngineeringResult


FamilyLadder = Callable[[DesignBrainService, BeamInputs], DesignBrainPreview]


class CtaIntent(StrEnum):
    """Presentation-neutral intent returned by a family decision."""

    APPLY_VERIFIED_PROPOSAL = "apply_verified_proposal"
    RETAIN_VERIFIED_DESIGN = "retain_verified_design"
    REVIEW_BLOCKER = "review_blocker"


@dataclass(frozen=True, slots=True)
class LadderStage:
    """One deterministic engineering stage owned by a family."""

    stage_id: str
    permitted_changes: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class ImprovementPolicy:
    """Defines when a candidate is materially better than the current design."""

    active_domains: tuple[str, ...]
    require_complete_compliance: bool = True
    require_target_band: bool = True
    allow_safe_progress_below_band: bool = False

    def accepts(
        self,
        current_utilisations: tuple[float, ...],
        proposed_utilisations: tuple[float, ...],
        *,
        complete_compliance: bool,
        reason: str,
        target_low: float,
        target_high: float,
    ) -> bool:
        if self.require_complete_compliance and not complete_compliance:
            return False
        if reason == "safe_shear_failure_repair":
            return bool(proposed_utilisations) and all(
                value <= target_high for value in proposed_utilisations
            )
        if self.allow_safe_progress_below_band and reason == "safe_overdesign_cleanup":
            return not proposed_utilisations or all(value <= target_high for value in proposed_utilisations)
        if not proposed_utilisations:
            return False
        if all(target_low <= value <= target_high for value in proposed_utilisations):
            return True
        # A verified material cleanup at zero demand cannot improve its
        # utilisation: both current and proposed values remain 0.00.  The
        # owning family has already proved that the proposal removes material,
        # changes the design and preserves every mandatory check, so equality
        # of utilisation must not suppress its Apply action.
        def distance(values: tuple[float, ...]) -> float:
            return sum(
                target_low - value if value < target_low else value - target_high if value > target_high else 0.0
                for value in values
            )

        if not self.require_target_band:
            return (
                all(value <= target_high for value in proposed_utilisations)
                and distance(proposed_utilisations) < distance(current_utilisations)
            )
        if not self.allow_safe_progress_below_band or reason != "proportion_balanced_candidate":
            return False
        if any(value > target_high for value in proposed_utilisations):
            return False

        return distance(proposed_utilisations) < distance(current_utilisations)


@dataclass(frozen=True, slots=True)
class RankingPolicy:
    """Ordered, reviewable candidate-ranking criteria."""

    criteria: tuple[str, ...] = (
        "complete_compliance",
        "target_distance",
        "new_near_failure_count",
        "fewest_changes",
        "least_congestion",
        "least_geometry_change",
        "least_material",
        "candidate_id",
    )

    def rank_key(self, evidence: CandidateEvidence) -> tuple:
        values = {
            "complete_compliance": 0 if evidence.compliant and evidence.mandatory_checks_complete else 1,
            "target_distance": evidence.target_distance,
            "new_near_failure_count": evidence.new_near_failure_count,
            "fewest_changes": evidence.edit_count,
            "least_congestion": evidence.constructability_penalty,
            "least_geometry_change": evidence.geometry_change_penalty,
            "least_material": evidence.material_quantity,
            "candidate_id": evidence.candidate_id,
        }
        return tuple(values[criterion] for criterion in self.criteria)


@dataclass(frozen=True, slots=True)
class ExactStopPolicy:
    reason_codes: tuple[str, ...] = ()
    required_stage_ids: tuple[str, ...] = ()
    require_exhausted_search: bool = True


@dataclass(frozen=True, slots=True)
class FamilyOutcome:
    status: str
    final_family: DesignFamily
    cta_intent: CtaIntent


@dataclass(frozen=True, slots=True)
class FamilyContract:
    family: DesignFamily
    owner_id: str
    entry_condition_id: str
    entry_condition: EntryCondition
    ladder_stages: tuple[LadderStage, ...]
    permitted_changes: tuple[str, ...]
    prohibited_changes: tuple[str, ...]
    required_checks: tuple[str, ...]
    improvement_policy: ImprovementPolicy
    ranking_policy: RankingPolicy = RankingPolicy()
    exact_stop_policy: ExactStopPolicy = ExactStopPolicy()
    blocker_contract_id: str = ""
    blocker_wording: tuple[tuple[str, str], ...] = ()
    action_intent: CtaIntent = CtaIntent.APPLY_VERIFIED_PROPOSAL
    pass_intent: CtaIntent = CtaIntent.RETAIN_VERIFIED_DESIGN
    blocked_intent: CtaIntent = CtaIntent.REVIEW_BLOCKER
    retain_compliant_on_optimisation_exhaustion: bool = False
    target_low: float = 0.85
    target_high: float = 1.0

    @property
    def terminal_reason_codes(self) -> tuple[str, ...]:
        """Compatibility property while exact-stop consumers migrate."""
        return self.exact_stop_policy.reason_codes

    def resolve_outcome(
        self,
        *,
        current_failed: bool,
        current_compliant: bool,
        current_in_band: bool,
        preview_accepted: bool,
        proposed_in_band: bool,
        exact_stop_proven: bool,
        preview_reason: str,
    ) -> FamilyOutcome:
        """Own the final status and CTA intent for this family."""

        if current_failed:
            status = "ACTION" if preview_accepted else "BLOCKED"
        elif current_in_band:
            return FamilyOutcome("PASS", DesignFamily.TARGET_BAND_REACHED, self.pass_intent)
        elif exact_stop_proven:
            return FamilyOutcome("PASS", DesignFamily.EXACT_STOP_PROVEN, self.pass_intent)
        elif preview_accepted and (
            proposed_in_band
            or (
                self.improvement_policy.allow_safe_progress_below_band
                and preview_reason in {"safe_overdesign_cleanup", "proportion_balanced_candidate"}
            )
        ):
            status = "ACTION"
        elif self.retain_compliant_on_optimisation_exhaustion and current_compliant:
            # Optimisation is optional once the authoritative current design
            # is compliant.  Exhausting the permitted optimisation ladder is
            # a retain-design PASS, never a red engineering blocker.
            return FamilyOutcome("PASS", self.family, self.pass_intent)
        else:
            status = "BLOCKED"
        intent = self.action_intent if status == "ACTION" else self.blocked_intent
        return FamilyOutcome(status, self.family, intent)

    def proves_exact_stop(
        self,
        *,
        preview_accepted: bool,
        preview_reason: str,
        candidates_attempted: int,
        completed_stage_ids: tuple[str, ...],
    ) -> bool:
        policy = self.exact_stop_policy
        return (
            not preview_accepted
            and preview_reason in policy.reason_codes
            and candidates_attempted > 0
            and bool(policy.required_stage_ids)
            and set(policy.required_stage_ids).issubset(completed_stage_ids)
        )

    def blocker_for(self, reason_code: str | None) -> str | None:
        if reason_code is None:
            return None
        canonical = reason_code.split(":", 1)[0]
        return next((text for code, text in self.blocker_wording if code == canonical), None)

    def active_utilisations(
        self,
        inputs: BeamInputs,
        result: EngineeringResult,
    ) -> tuple[float, ...]:
        """Return only the target-band domains owned by this family.

        Mandatory checks still verify the complete proposal.  This narrower
        tuple prevents a passing preservation domain (for example bending in
        a shear repair) from being incorrectly required to enter the
        optimisation band before Apply can be authorised.
        """

        values: list[float] = []
        domains = self.improvement_policy.active_domains
        if "bending" in domains and abs(float(inputs.actions.bending_moment_knm)) > 1e-9:
            values.append(float(result.families.get("bending", {}).get("util", 0.0) or 0.0))
        if "shear" in domains and abs(float(inputs.actions.shear_force_kn)) > 1e-9:
            shear = result.families.get("shear", {})
            capacity = float(shear.get("phi_Vu", 0.0) or 0.0)
            values.append(
                abs(float(inputs.actions.shear_force_kn)) / capacity
                if capacity > 0.0
                else float("inf")
            )
        if "serviceability" in domains:
            values.append(
                float(result.families.get("serviceability", {}).get("deflection_util", 0.0) or 0.0)
            )
        return tuple(values)


@dataclass(frozen=True, slots=True)
class FamilyOwner:
    contract: FamilyContract
    ladder: FamilyLadder

    @property
    def family(self) -> DesignFamily:
        return self.contract.family

    def preview(self, current: BeamInputs, service: DesignBrainService) -> DesignBrainPreview:
        with service.family_contract(self.contract):
            preview = self.ladder(service, current)
        service.last_search_metrics["owner_id"] = self.contract.owner_id
        service.last_search_metrics["declared_stage_ids"] = tuple(
            stage.stage_id for stage in self.contract.ladder_stages
        )
        if preview.reason in self.contract.exact_stop_policy.reason_codes:
            service.last_search_metrics["completed_stage_ids"] = tuple(
                stage.stage_id for stage in self.contract.ladder_stages
            )
        return preview


def _bending_failure(service: DesignBrainService, current: BeamInputs) -> DesignBrainPreview:
    return service.preview(current)


def _shear_failure(service: DesignBrainService, current: BeamInputs) -> DesignBrainPreview:
    return service.preview_shear_only(current)


def _shear_failure_bending_optimise(service: DesignBrainService, current: BeamInputs) -> DesignBrainPreview:
    return service.preview_shear_failure_bending_optimise(current)


def _combined_failure(service: DesignBrainService, current: BeamInputs) -> DesignBrainPreview:
    return service.preview_combined_failure(current)


def _bending_overdesign(service: DesignBrainService, current: BeamInputs) -> DesignBrainPreview:
    return service.preview_bending_overdesign(current)


def _bending_failure_shear_cleanup(service: DesignBrainService, current: BeamInputs) -> DesignBrainPreview:
    return service.preview_bending_failure_shear_cleanup(current)


def _shear_overdesign(service: DesignBrainService, current: BeamInputs) -> DesignBrainPreview:
    return service.preview_shear_overdesign(current)


def _combined_overdesign(service: DesignBrainService, current: BeamInputs) -> DesignBrainPreview:
    return service.preview_combined_overdesign(current)


def _serviceability(service: DesignBrainService, current: BeamInputs) -> DesignBrainPreview:
    return service.preview_serviceability(current)


def _geometry_detailing(service: DesignBrainService, current: BeamInputs) -> DesignBrainPreview:
    return service.preview_geometry_detailing(current)


_NEVER_CHANGE = ("actions", "serviceability_inputs", "materials", "supports", "persistence", "widget_state")


def _contract(
    family: DesignFamily,
    owner_id: str,
    entry_condition_id: str,
    stages: tuple[LadderStage, ...],
    permitted: tuple[str, ...],
    checks: tuple[str, ...],
    *,
    active_domains: tuple[str, ...],
    allow_safe_progress: bool = False,
    require_target_band: bool = True,
    retain_compliant_on_optimisation_exhaustion: bool = False,
    exact_reasons: tuple[str, ...] = (),
) -> FamilyContract:
    return FamilyContract(
        family=family,
        owner_id=owner_id,
        entry_condition_id=entry_condition_id,
        entry_condition=ENTRY_CONDITIONS[family],
        ladder_stages=stages,
        permitted_changes=permitted,
        prohibited_changes=_NEVER_CHANGE,
        required_checks=checks,
        improvement_policy=ImprovementPolicy(
            active_domains,
            require_target_band=require_target_band,
            allow_safe_progress_below_band=allow_safe_progress,
        ),
        retain_compliant_on_optimisation_exhaustion=retain_compliant_on_optimisation_exhaustion,
        exact_stop_policy=ExactStopPolicy(
            reason_codes=exact_reasons,
            required_stage_ids=tuple(stage.stage_id for stage in stages),
        ),
        blocker_contract_id=family.value.lower(),
        blocker_wording=tuple(
            (item.reason_code, item.sentence)
            for item in FAMILY_TEXT_CONTRACTS[family].blockers
        ),
    )


FAMILY_OWNERS: dict[DesignFamily, FamilyOwner] = {
    DesignFamily.GEOMETRY_DETAILING_GOVERNS: FamilyOwner(_contract(
        DesignFamily.GEOMETRY_DETAILING_GOVERNS, "geometry_detailing", "invalid_geometry_or_reinforcement_fit",
        (LadderStage("repair_arrangement", ("bottom", "top", "shear")), LadderStage("repair_geometry", ("width_mm", "depth_mm"))),
        ("bottom", "top", "shear", "width_mm", "depth_mm"), ("geometry", "reinforcement_fit"), active_domains=("geometry",),
    ), _geometry_detailing),
    DesignFamily.SERVICEABILITY_GOVERNS: FamilyOwner(_contract(
        DesignFamily.SERVICEABILITY_GOVERNS, "serviceability", "active_sls_check_fails",
        (LadderStage("redistribute_reinforcement", ("bottom",)), LadderStage("increase_stiffness", ("depth_mm", "width_mm"))),
        ("bottom", "depth_mm", "width_mm"), ("crack_control", "serviceability", "bending", "shear", "reinforcement_fit"), active_domains=("serviceability",),
    ), _serviceability),
    DesignFamily.COMBINED_OVERDESIGN: FamilyOwner(_contract(
        DesignFamily.COMBINED_OVERDESIGN, "combined_overdesign", "bending_and_shear_below_target",
        (LadderStage("reduce_shear_reinforcement", ("shear",)), LadderStage("reduce_bending_reinforcement", ("bottom",)), LadderStage("reduce_geometry_and_redesign", ("width_mm", "depth_mm", "bottom", "shear"))),
        ("bottom", "shear", "width_mm", "depth_mm"), ("bending", "shear", "ductility", "reinforcement_fit"), active_domains=("bending", "shear"), allow_safe_progress=True, retain_compliant_on_optimisation_exhaustion=True,
        exact_reasons=("minimum_reinforcement_geometry_exhausted", "ductility_geometry_exhausted"),
    ), _combined_overdesign),
    DesignFamily.BENDING_AND_SHEAR_FAIL_GOVERN: FamilyOwner(_contract(
        DesignFamily.BENDING_AND_SHEAR_FAIL_GOVERN, "combined_failure", "bending_and_shear_fail",
        (LadderStage("repair_reinforcement", ("bottom", "shear")), LadderStage("increase_geometry_and_redesign", ("width_mm", "depth_mm", "bottom", "shear"))),
        ("bottom", "shear", "width_mm", "depth_mm"), ("bending", "shear", "ductility", "reinforcement_fit"), active_domains=("bending", "shear"), require_target_band=False,
    ), _combined_failure),
    DesignFamily.SHEAR_FAIL_GOVERNS: FamilyOwner(_contract(
        DesignFamily.SHEAR_FAIL_GOVERNS, "shear_failure", "shear_fails_bending_not_overdesigned",
        (LadderStage("repair_ligatures", ("shear",)), LadderStage("increase_width", ("width_mm",)), LadderStage("increase_depth_and_redesign", ("depth_mm", "bottom", "shear"))),
        ("shear", "width_mm", "depth_mm", "bottom"), ("shear", "bending", "ductility", "reinforcement_fit"), active_domains=("shear",), require_target_band=False,
    ), _shear_failure),
    DesignFamily.SHEAR_FAIL_BENDING_OPTIMISE_GOVERNS: FamilyOwner(_contract(
        DesignFamily.SHEAR_FAIL_BENDING_OPTIMISE_GOVERNS, "shear_failure_bending_optimise", "shear_fails_bending_below_target",
        (LadderStage("repair_ligatures", ("shear",)), LadderStage("coordinate_longitudinal_reduction", ("bottom", "shear")), LadderStage("resize_and_redesign", ("width_mm", "depth_mm", "bottom", "shear"))),
        ("bottom", "shear", "width_mm", "depth_mm"), ("shear", "bending", "ductility", "reinforcement_fit"), active_domains=("shear", "bending"), require_target_band=False,
    ), _shear_failure_bending_optimise),
    DesignFamily.BENDING_FAIL_GOVERNS: FamilyOwner(_contract(
        DesignFamily.BENDING_FAIL_GOVERNS, "bending_failure", "bending_fails_shear_not_overdesigned",
        (LadderStage("increase_bottom_reinforcement", ("bottom",)), LadderStage("add_reinforcement_layer", ("bottom",)), LadderStage("increase_depth", ("depth_mm", "bottom")), LadderStage("increase_width_at_ratio_limit", ("width_mm", "depth_mm", "bottom"))),
        ("bottom", "width_mm", "depth_mm"), ("bending", "ductility", "minimum_tensile", "reinforcement_fit"), active_domains=("bending",),
    ), _bending_failure),
    DesignFamily.BENDING_FAIL_SHEAR_OVERDESIGN_GOVERNS: FamilyOwner(_contract(
        DesignFamily.BENDING_FAIL_SHEAR_OVERDESIGN_GOVERNS, "bending_failure_shear_cleanup", "bending_fails_shear_below_target",
        (LadderStage("repair_bending", ("bottom",)), LadderStage("reduce_shear_excess", ("shear",)), LadderStage("coordinate_geometry", ("width_mm", "depth_mm", "bottom", "shear"))),
        ("bottom", "shear", "width_mm", "depth_mm"), ("bending", "shear", "ductility", "minimum_tensile", "reinforcement_fit"), active_domains=("bending", "shear"), require_target_band=False,
    ), _bending_failure_shear_cleanup),
    DesignFamily.BENDING_OVERDESIGN_GOVERNS: FamilyOwner(_contract(
        DesignFamily.BENDING_OVERDESIGN_GOVERNS, "bending_overdesign", "bending_below_target_other_active_domains_compliant",
        (LadderStage("reduce_bottom_reinforcement", ("bottom",)), LadderStage("remove_unnecessary_layer", ("bottom",)), LadderStage("reduce_geometry_and_redesign", ("width_mm", "depth_mm", "bottom")), LadderStage("preserve_near_limit_shear", ("shear",))),
        ("bottom", "width_mm", "depth_mm", "shear"), ("bending", "shear", "ductility", "minimum_tensile", "reinforcement_fit"), active_domains=("bending",), allow_safe_progress=True, retain_compliant_on_optimisation_exhaustion=True,
        exact_reasons=("minimum_reinforcement_geometry_exhausted", "ductility_geometry_exhausted"),
    ), _bending_overdesign),
    DesignFamily.SHEAR_OVERDESIGN_GOVERNS: FamilyOwner(_contract(
        DesignFamily.SHEAR_OVERDESIGN_GOVERNS, "shear_overdesign", "shear_below_target_other_active_domains_compliant",
        (LadderStage("increase_spacing", ("shear",)), LadderStage("reduce_ligature_size_or_legs", ("shear",)), LadderStage("remove_unrequired_ligatures", ("shear",)), LadderStage("reduce_width_and_redesign", ("width_mm", "bottom", "shear"))),
        ("shear", "width_mm", "bottom"), ("shear", "bending", "ductility", "reinforcement_fit"), active_domains=("shear",), allow_safe_progress=True, retain_compliant_on_optimisation_exhaustion=True,
        exact_reasons=("minimum_shear_reinforcement_exhausted",),
    ), _shear_overdesign),
}


TERMINAL_FAMILIES = {
    DesignFamily.TARGET_BAND_REACHED,
    DesignFamily.EXACT_STOP_PROVEN,
    DesignFamily.LOCKED_NO_REPAIR,
}


def _terminal_contract(
    family: DesignFamily,
    owner_id: str,
    entry_condition_id: str,
    stage_id: str,
    checks: tuple[str, ...],
) -> FamilyContract:
    return FamilyContract(
        family=family,
        owner_id=owner_id,
        entry_condition_id=entry_condition_id,
        entry_condition=ENTRY_CONDITIONS[family],
        ladder_stages=(LadderStage(stage_id, ("none",)),),
        permitted_changes=("none",),
        prohibited_changes=("bottom", "top", "shear", "width_mm", "depth_mm", *_NEVER_CHANGE),
        required_checks=checks,
        improvement_policy=ImprovementPolicy(("terminal_verification",), require_target_band=False),
        exact_stop_policy=ExactStopPolicy(required_stage_ids=(stage_id,)),
        blocker_contract_id=family.value.lower(),
        blocker_wording=tuple(
            (item.reason_code, item.sentence)
            for item in FAMILY_TEXT_CONTRACTS[family].blockers
        ),
    )


TERMINAL_CONTRACTS: dict[DesignFamily, FamilyContract] = {
    DesignFamily.TARGET_BAND_REACHED: _terminal_contract(
        DesignFamily.TARGET_BAND_REACHED, "target_band", "all_active_domains_in_target_band",
        "verify_active_target_band", ("bending", "shear", "serviceability", "crack_control", "reinforcement_fit"),
    ),
    DesignFamily.EXACT_STOP_PROVEN: _terminal_contract(
        DesignFamily.EXACT_STOP_PROVEN, "exact_stop", "active_family_search_exhausted_at_verified_limit",
        "verify_exact_stop_evidence", ("bending", "shear", "ductility", "minimum_tensile", "serviceability", "crack_control", "reinforcement_fit"),
    ),
    DesignFamily.LOCKED_NO_REPAIR: _terminal_contract(
        DesignFamily.LOCKED_NO_REPAIR, "locked_no_repair", "required_repair_prevented_by_explicit_lock",
        "verify_lock_and_failed_check", ("geometry", "bending", "shear", "ductility", "minimum_tensile", "serviceability", "crack_control", "reinforcement_fit"),
    ),
}


FAMILY_CONTRACTS: dict[DesignFamily, FamilyContract] = {
    **{family: owner.contract for family, owner in FAMILY_OWNERS.items()},
    **TERMINAL_CONTRACTS,
}


_CHANGE_OWNER = {
    "width_mm": "width_mm",
    "depth_mm": "depth_mm",
    "bottom_bars": "bottom",
    "bottom_diameter_mm": "bottom",
    "layer_count": "bottom",
    "shear_diameter_mm": "shear",
    "shear_legs": "shear",
    "shear_spacing_mm": "shear",
}


def assert_permitted_changes(contract: FamilyContract, change_types: tuple[str, ...]) -> None:
    """Reject proposal leakage across family-owned mutation boundaries."""

    permitted = set(contract.permitted_changes)
    unknown = tuple(change for change in change_types if change not in _CHANGE_OWNER)
    forbidden = tuple(
        change for change in change_types
        if change in _CHANGE_OWNER and _CHANGE_OWNER[change] not in permitted
    )
    if unknown or forbidden:
        details = ", ".join((*unknown, *forbidden))
        raise ValueError(f"{contract.family.value} proposed undeclared changes: {details}")


def assert_candidate_proposal_permitted(
    contract: FamilyContract,
    current: BeamInputs,
    proposal,
) -> None:
    """Compare the complete proposal so hidden, undisplayed mutations cannot leak."""

    groups = {
        "width_mm": ((current.width_mm, proposal.width_mm),),
        "depth_mm": ((current.depth_mm, proposal.depth_mm),),
        "geometry": (
            (current.span_mm, proposal.span_mm),
            (current.section_shape, proposal.section_shape),
        ),
        "bottom": (
            (current.bottom.mode, proposal.bottom_mode),
            (current.bottom.bars, proposal.bottom_bars),
            (current.bottom.spacing_mm, proposal.bottom_spacing_mm),
            (current.bottom.diameter_mm, proposal.bottom_diameter_mm),
            (current.bottom.cover_mm, proposal.bottom_cover_mm),
        ),
        "top": (
            (current.top.mode, proposal.top_mode),
            (current.top.bars, proposal.top_bars),
            (current.top.spacing_mm, proposal.top_spacing_mm),
            (current.top.diameter_mm, proposal.top_diameter_mm),
            (current.top.cover_mm, proposal.top_cover_mm),
        ),
        "shear": (
            (current.shear.diameter_mm, proposal.shear_diameter_mm),
            (current.shear.legs, proposal.shear_legs),
            (current.shear.spacing_mm, proposal.shear_spacing_mm),
        ),
        "materials": (
            (current.materials.concrete_strength_mpa, proposal.concrete_strength_mpa),
            (current.materials.reinforcement_strength_mpa, proposal.reinforcement_strength_mpa),
        ),
        "actions": (
            (current.actions.bending_moment_knm, proposal.bending_moment_knm),
            (current.actions.torsion_knm, proposal.torsion_knm),
            (current.actions.shear_force_kn, proposal.shear_force_kn),
            (current.actions.axial_force_kn, proposal.axial_force_kn),
        ),
        "supports": (
            (current.supports.left_type, proposal.left_support),
            (current.supports.right_type, proposal.right_support),
        ),
        "serviceability_inputs": (
            (current.serviceability.moment_knm, proposal.sls_moment_knm),
            (current.serviceability.shear_kn, proposal.sls_shear_kn),
            (current.serviceability.permanent_udl_knm_per_m, proposal.sls_permanent_udl_knm_per_m),
            (current.serviceability.imposed_udl_knm_per_m, proposal.sls_imposed_udl_knm_per_m),
            (current.serviceability.equivalent_udl_knm_per_m, proposal.sls_equivalent_udl_knm_per_m),
        ),
    }
    changed_groups = tuple(
        group for group, comparisons in groups.items()
        if any(before != after for before, after in comparisons)
    )
    forbidden = set(contract.prohibited_changes)
    permitted = set(contract.permitted_changes)
    leaks = tuple(group for group in changed_groups if group in forbidden or group not in permitted)
    if leaks:
        raise ValueError(
            f"{contract.family.value} proposal crosses owned boundaries: {', '.join(leaks)}"
        )
