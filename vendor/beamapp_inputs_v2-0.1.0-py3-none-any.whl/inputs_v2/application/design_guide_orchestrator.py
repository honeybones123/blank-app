"""Single typed orchestration boundary for V2 Design Guide families."""

from __future__ import annotations

from dataclasses import dataclass

from inputs_v2.application.design_brain_families import DesignFamily, classify_design_family
from inputs_v2.application.design_brain_service import DesignBrainPreview, DesignBrainService
from inputs_v2.application.design_brain_decision import DecisionStatus, FamilyDecision, SearchEvidence
from inputs_v2.application.engineering_advice import (
    EngineeringAdviceResult,
    TargetBandBlocker,
    authoritative_checks,
    clause_references_from_checks,
    effects_for_changes,
    verified_changes,
)
from inputs_v2.application.design_brain.family_owners import (
    FAMILY_CONTRACTS,
    FAMILY_OWNERS,
    assert_candidate_proposal_permitted,
    assert_permitted_changes,
)
from inputs_v2.application.design_brain.text_contracts import FAMILY_TEXT_CONTRACTS
from inputs_v2.application.candidate_evaluation import complete_compliance
from inputs_v2.domain.beam_inputs import BeamInputs


@dataclass(frozen=True, slots=True)
class DesignGuideDecision:
    family: DesignFamily
    preview: DesignBrainPreview
    evidence: dict[str, object]


class DesignGuideOrchestrator:
    """Classify once, then delegate to exactly one family-owned ladder."""

    def __init__(self) -> None:
        self._service = DesignBrainService()

    @staticmethod
    def registered_families() -> tuple[DesignFamily, ...]:
        """Return every contract family handled by this boundary."""
        return tuple(DesignFamily)

    @staticmethod
    def _active_utilisations(current: BeamInputs, result) -> tuple[float, ...]:
        values: list[float] = []
        if abs(float(current.actions.bending_moment_knm)) > 1e-9:
            values.append(float(result.families.get("bending", {}).get("util", 0.0) or 0.0))
        if abs(float(current.actions.shear_force_kn)) > 1e-9:
            shear = result.families.get("shear", {})
            capacity = float(shear.get("phi_Vu", 0.0) or 0.0)
            values.append(abs(float(current.actions.shear_force_kn)) / capacity if capacity > 0.0 else float("inf"))
        if DesignBrainService._has_sls(current):
            values.append(float(result.families.get("serviceability", {}).get("deflection_util", 0.0) or 0.0))
        return tuple(values)

    def decide(self, current: BeamInputs) -> FamilyDecision:
        result = self._service._calculator.calculate_current(current).result
        if result is None:
            raise ValueError("calculation result is stale")
        family = classify_design_family(result, current)
        selected_family = family
        decision_contract = FAMILY_CONTRACTS[selected_family]
        selected_text_contract = FAMILY_TEXT_CONTRACTS[selected_family]
        bending_util = float(result.families.get("bending", {}).get("util", 0.0) or 0.0)
        shear_family = result.families.get("shear", {})
        shear_capacity = float(shear_family.get("phi_Vu", 0.0) or 0.0)
        shear_util = abs(float(current.actions.shear_force_kn)) / shear_capacity if shear_capacity > 0.0 else 0.0
        owner = FAMILY_OWNERS.get(family)
        preview = (
            owner.preview(current, self._service)
            if owner is not None
            else self._service.preview_terminal(current, family.value.lower())
        )
        all_current_utils = self._active_utilisations(current, result)
        current_utils = decision_contract.active_utilisations(current, result)
        proposed_utils = decision_contract.active_utilisations(current, preview.after)
        current_failed = any(value > 1.0 for value in all_current_utils)
        # A numerical utilisation subset is not sufficient to declare a
        # terminal result.  The sole classifier must also have selected the
        # terminal family; otherwise zero-demand reinforcement cleanup,
        # detailing, or serviceability work could be hidden by one ULS value
        # that happens to be in band.
        current_in_band = (
            family is DesignFamily.TARGET_BAND_REACHED
            and bool(all_current_utils)
            and all(0.85 <= value <= 1.0 for value in all_current_utils)
        )
        proposed_in_band = bool(proposed_utils) and all(0.85 <= value <= 1.0 for value in proposed_utils)
        policy_accepted = preview.accepted and decision_contract.improvement_policy.accepts(
            current_utils,
            proposed_utils,
            complete_compliance=complete_compliance(preview.after),
            reason=preview.reason,
            target_low=decision_contract.target_low,
            target_high=decision_contract.target_high,
        )
        candidates_attempted = max(
            int(self._service.last_search_metrics.get("candidates_attempted", 0) or 0),
            int(self._service.last_search_metrics.get("additional_evaluations", 0) or 0),
        )
        declared_stage_ids = tuple(self._service.last_search_metrics.get("declared_stage_ids", ()) or ())
        completed_stage_ids = tuple(self._service.last_search_metrics.get("completed_stage_ids", ()) or ())
        exact_stop = decision_contract.proves_exact_stop(
            preview_accepted=policy_accepted,
            preview_reason=preview.reason,
            candidates_attempted=candidates_attempted,
            completed_stage_ids=completed_stage_ids,
        )
        changes = verified_changes(current, preview.candidate.proposal, preview.candidate.row_counts)
        if owner is not None:
            assert_candidate_proposal_permitted(owner.contract, current, preview.candidate.proposal)
            assert_permitted_changes(owner.contract, tuple(change.change_type for change in changes))
        outcome = decision_contract.resolve_outcome(
            current_failed=current_failed,
            current_compliant=complete_compliance(result),
            current_in_band=current_in_band,
            preview_accepted=policy_accepted,
            proposed_in_band=proposed_in_band,
            exact_stop_proven=exact_stop,
            preview_reason=preview.reason,
        )
        status = DecisionStatus(outcome.status)
        family = outcome.final_family
        if status is DecisionStatus.PASS:
            changes = ()
        apply_allowed = (
            outcome.cta_intent.value == "apply_verified_proposal"
            and policy_accepted
            and bool(changes)
        )
        text_contract = FAMILY_TEXT_CONTRACTS[family]
        heading = text_contract.title_for(status.value)
        blocker_code = preview.reason
        blocker = None
        if status is DecisionStatus.BLOCKED:
            blocker = decision_contract.blocker_for(preview.reason)
            if preview.accepted and not policy_accepted:
                blocker_code = "proposal_outside_target_band"
                blocker = "The assessed revision remains outside the required target band"
            elif blocker is None:
                blocker = "The selected family did not provide a verified engineering blocker for this outcome"
        effects = effects_for_changes(changes, selected_text_contract.engineering_purpose)
        required_checks = owner.contract.required_checks if owner is not None else selected_text_contract.required_checks
        current_checks = authoritative_checks(current, result, required_checks)
        proposed_checks = authoritative_checks(current, preview.after, required_checks)
        references = clause_references_from_checks(current_checks + proposed_checks)
        governing_failed = next((check for check in current_checks if check.status == "fail"), None)
        typed_blocker = None if blocker is None else TargetBandBlocker(
            check_id=governing_failed.check_id if governing_failed is not None else "family_search",
            blocker_code=blocker_code,
            blocked_action=selected_text_contract.engineering_purpose,
            governing_requirement=blocker,
            clause_reference=governing_failed.clause_reference if governing_failed is not None else None,
        )
        advice = EngineeringAdviceResult(
            current_checks=current_checks,
            proposed_checks=proposed_checks,
            recommended_changes=changes,
            engineering_effects=effects or (("The selected family has exhausted its verified search without a safe improving candidate.",) if exact_stop else ()),
            governing_check=family.value,
            clause_references=references,
            verified_compliance=status in {DecisionStatus.PASS, DecisionStatus.ACTION} and (not current_failed or policy_accepted),
            apply_allowed=apply_allowed,
            blocked_reason=blocker,
            outcome_type=family.value,
            blocker=typed_blocker,
        )
        return FamilyDecision(
            family=family,
            status=status,
            display_heading=heading,
            candidate=preview.candidate,
            current_result=result,
            proposed_result=preview.after,
            advice=advice,
            apply_allowed=apply_allowed,
            reason=preview.reason,
            changed_fields=preview.changed_fields,
            search_evidence=SearchEvidence(
                candidates_attempted=candidates_attempted,
                candidates_valid=int(self._service.last_search_metrics.get("candidates_valid", 0) or 0),
                geometry_attempted=int(self._service.last_search_metrics.get("geometry_evaluations", 0) or 0) > 0,
                reinforcement_attempted=int(self._service.last_search_metrics.get("reinforcement_evaluations", 0) or 0) > 0,
                governing_blocker=blocker,
                exhausted=exact_stop,
                declared_stage_ids=declared_stage_ids,
                completed_stage_ids=completed_stage_ids,
            ),
        )

    def preview(self, current: BeamInputs) -> DesignGuideDecision:
        """Compatibility wrapper retained while callers migrate to decide()."""
        decision = self.decide(current)
        preview = DesignBrainPreview(
            decision.candidate,
            decision.current_result,
            decision.proposed_result or decision.current_result,
            decision.changed_fields,
            decision.apply_allowed,
            decision.reason,
        )
        return DesignGuideDecision(decision.family, preview, {
            "family": decision.family.value,
            "source_revision": current.revision,
            "status": decision.status.value,
        })
