"""V2-owned Design Guide family classification boundary.

The identifiers and priority are copied from the V1 family contract, but the
classifier consumes only typed V2 results and never imports the V1 runtime.
"""

from __future__ import annotations

from enum import StrEnum
from dataclasses import dataclass
from typing import Callable

from inputs_v2.domain.engineering_result import EngineeringResult
from inputs_v2.domain.beam_inputs import BeamInputs


class DesignFamily(StrEnum):
    EXACT_STOP_PROVEN = "EXACT_STOP_PROVEN"
    LOCKED_NO_REPAIR = "LOCKED_NO_REPAIR"
    GEOMETRY_DETAILING_GOVERNS = "GEOMETRY_DETAILING_GOVERNS"
    BENDING_AND_SHEAR_FAIL_GOVERN = "BENDING_AND_SHEAR_FAIL_GOVERN"
    BENDING_FAIL_SHEAR_OVERDESIGN_GOVERNS = "BENDING_FAIL_SHEAR_OVERDESIGN_GOVERNS"
    SHEAR_FAIL_BENDING_OPTIMISE_GOVERNS = "SHEAR_FAIL_BENDING_OPTIMISE_GOVERNS"
    BENDING_FAIL_GOVERNS = "BENDING_FAIL_GOVERNS"
    SHEAR_FAIL_GOVERNS = "SHEAR_FAIL_GOVERNS"
    SERVICEABILITY_GOVERNS = "SERVICEABILITY_GOVERNS"
    COMBINED_OVERDESIGN = "COMBINED_OVERDESIGN"
    BENDING_OVERDESIGN_GOVERNS = "BENDING_OVERDESIGN_GOVERNS"
    SHEAR_OVERDESIGN_GOVERNS = "SHEAR_OVERDESIGN_GOVERNS"
    TARGET_BAND_REACHED = "TARGET_BAND_REACHED"


V1_FAMILY_PRIORITY: tuple[DesignFamily, ...] = tuple(DesignFamily)


@dataclass(frozen=True, slots=True)
class DesignSignals:
    geometry_invalid: bool
    bending_utilisation: float
    shear_utilisation: float
    bending_domain: bool
    shear_domain: bool
    zero_bending_with_reinforcement: bool
    zero_shear_with_reinforcement: bool
    serviceability_failed: bool

    @property
    def active_utilisations(self) -> tuple[float, ...]:
        return tuple(
            value
            for active, value in (
                (self.bending_domain, self.bending_utilisation),
                (self.shear_domain, self.shear_utilisation),
            )
            if active
        )


EntryCondition = Callable[[DesignSignals], bool]


def design_signals(result: EngineeringResult, inputs: BeamInputs | None) -> DesignSignals:
    bending = result.families.get("bending", {})
    shear = result.families.get("shear", {})
    bend_util = float(bending.get("util", 0.0) or 0.0)
    phi_vu = float(shear.get("phi_Vu", 0.0) or 0.0)
    shear_action = abs(float(shear.get("V_eq", 0.0) or 0.0))
    shear_util = shear_action / phi_vu if phi_vu > 0 else 0.0
    bending_domain = inputs is None or abs(float(inputs.actions.bending_moment_knm)) > 1e-9
    shear_domain = inputs is None or (
        abs(float(inputs.actions.shear_force_kn)) > 1e-9
        or inputs.shear.diameter_mm > 0
        or inputs.shear.legs > 0
    )
    geometry_invalid = bool(inputs is not None and (
        inputs.depth_mm / inputs.width_mm > 2.0
        or (inputs.shear.diameter_mm == 0 and inputs.shear.legs != 0)
    ))
    zero_bending = bool(inputs is not None and not bending_domain and (
        inputs.bottom.bars > 0 or inputs.bottom.diameter_mm > 0
    ))
    zero_shear = bool(inputs is not None and abs(float(inputs.actions.shear_force_kn)) < 1e-9 and (
        inputs.shear.diameter_mm > 0 or inputs.shear.legs > 0
    ))
    serviceability = result.families.get("serviceability", {})
    crack = result.families.get("crack_control", {})
    serviceability_failed = (
        str(serviceability.get("status", "")).upper() == "FAIL"
        or str(crack.get("status", "")).upper() == "FAIL"
    )
    return DesignSignals(
        geometry_invalid, bend_util, shear_util, bending_domain, shear_domain,
        zero_bending, zero_shear, serviceability_failed,
    )


ENTRY_CONDITIONS: dict[DesignFamily, EntryCondition] = {
    DesignFamily.GEOMETRY_DETAILING_GOVERNS: lambda s: s.geometry_invalid,
    DesignFamily.BENDING_AND_SHEAR_FAIL_GOVERN: lambda s: s.bending_utilisation > 1.0 and s.shear_utilisation > 1.0,
    DesignFamily.BENDING_FAIL_SHEAR_OVERDESIGN_GOVERNS: lambda s: s.bending_utilisation > 1.0 and s.shear_utilisation < 0.85,
    DesignFamily.SHEAR_FAIL_BENDING_OPTIMISE_GOVERNS: lambda s: s.shear_utilisation > 1.0 and s.bending_utilisation < 0.85,
    DesignFamily.BENDING_FAIL_GOVERNS: lambda s: s.bending_utilisation > 1.0,
    DesignFamily.SHEAR_FAIL_GOVERNS: lambda s: s.shear_utilisation > 1.0,
    DesignFamily.SERVICEABILITY_GOVERNS: lambda s: s.serviceability_failed,
    DesignFamily.COMBINED_OVERDESIGN: lambda s: (
        (s.zero_bending_with_reinforcement and s.zero_shear_with_reinforcement)
        or (not s.serviceability_failed and s.bending_utilisation < 0.85 and s.shear_utilisation < 0.85 and s.bending_domain and s.shear_domain)
    ),
    DesignFamily.BENDING_OVERDESIGN_GOVERNS: lambda s: (
        s.zero_bending_with_reinforcement
        or (not s.serviceability_failed and s.bending_utilisation < 0.85 and not s.shear_domain)
        or (not s.serviceability_failed and s.bending_utilisation < 0.85 and 0.85 <= s.shear_utilisation <= 1.0)
    ),
    DesignFamily.SHEAR_OVERDESIGN_GOVERNS: lambda s: (
        s.zero_shear_with_reinforcement
        or (not s.serviceability_failed and s.shear_domain and s.shear_utilisation < 0.85 and not s.bending_domain)
        or (not s.serviceability_failed and s.shear_domain and s.shear_utilisation < 0.85 and 0.85 <= s.bending_utilisation <= 1.0)
    ),
    DesignFamily.TARGET_BAND_REACHED: lambda s: (
        bool(s.active_utilisations)
        and all(0.85 <= value <= 1.0 for value in s.active_utilisations)
    ),
    DesignFamily.EXACT_STOP_PROVEN: lambda s: False,
    DesignFamily.LOCKED_NO_REPAIR: lambda s: False,
}


CLASSIFICATION_PRIORITY: tuple[DesignFamily, ...] = (
    DesignFamily.GEOMETRY_DETAILING_GOVERNS,
    DesignFamily.BENDING_AND_SHEAR_FAIL_GOVERN,
    DesignFamily.BENDING_FAIL_SHEAR_OVERDESIGN_GOVERNS,
    DesignFamily.BENDING_FAIL_GOVERNS,
    DesignFamily.SHEAR_FAIL_BENDING_OPTIMISE_GOVERNS,
    DesignFamily.SHEAR_FAIL_GOVERNS,
    DesignFamily.COMBINED_OVERDESIGN,
    DesignFamily.BENDING_OVERDESIGN_GOVERNS,
    DesignFamily.SHEAR_OVERDESIGN_GOVERNS,
    DesignFamily.SERVICEABILITY_GOVERNS,
    DesignFamily.TARGET_BAND_REACHED,
)


def classify_design_family(result: EngineeringResult, inputs: BeamInputs | None = None) -> DesignFamily:
    """Classify once using the executable family entry-condition registry."""
    signals = design_signals(result, inputs)
    for family in CLASSIFICATION_PRIORITY:
        if ENTRY_CONDITIONS[family](signals):
            return family
    return DesignFamily.EXACT_STOP_PROVEN
