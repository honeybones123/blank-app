"""Typed, calculator-backed Design Brain orchestration for V2."""

from __future__ import annotations

from contextlib import contextmanager
from dataclasses import replace

from inputs_v2.application.calculation_coordinator import CalculationCoordinator
from inputs_v2.application.design_brain_apply import Candidate, ApplyOutcome, apply_candidate, propose_fixture_bottom_reinforcement
from inputs_v2.domain.beam_inputs import BeamInputs
from inputs_v2.domain.engineering_result import EngineeringResult
from inputs_v2.engineering.engineering_calculator import EngineeringCalculator
from inputs_v2.engineering.reinforcement_fit import practical_row_counts
from inputs_v2.application.candidate_evaluation import complete_compliance as _complete_compliance, evaluate_candidate
from inputs_v2.application.design_brain.candidate_ranking import (
    candidate_rank_key,
)
from inputs_v2.application.design_brain.preview import DesignBrainPreview
from inputs_v2.application.design_brain.serviceability_pipeline import ServiceabilityCandidatePipeline
from inputs_v2.application.design_brain.combined_overdesign_pipeline import CombinedOverdesignPipeline
from inputs_v2.application.design_brain.shear_failure_pipeline import ShearFailurePipeline
from inputs_v2.application.design_brain.bending_overdesign_pipeline import BendingOverdesignPipeline
from inputs_v2.application.design_brain.shear_overdesign_pipeline import ShearOverdesignPipeline
from inputs_v2.application.design_brain.combined_failure_pipeline import CombinedFailurePipeline
from inputs_v2.application.design_brain.bending_failure_pipeline import BendingFailurePipeline
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Iterator
    from inputs_v2.application.design_brain.family_owners import FamilyContract
    from inputs_v2.application.design_brain_decision import FamilyDecision


class DesignBrainService:
    """Generate and evaluate proposals without accessing UI or session state."""

    def __init__(self) -> None:
        self._calculator = CalculationCoordinator(EngineeringCalculator())
        self.last_search_metrics: dict[str, float | int | bool] = {"proportion_triggered": False, "additional_evaluations": 0}
        self._active_family_contract = None

    @contextmanager
    def family_contract(self, contract: "FamilyContract") -> "Iterator[None]":
        """Bind family-owned ranking rules for exactly one ladder execution."""

        previous = self._active_family_contract
        self._active_family_contract = contract
        try:
            yield
        finally:
            self._active_family_contract = previous

    def preview_terminal(self, current: BeamInputs, reason: str) -> DesignBrainPreview:
        """Return a no-mutation preview for an already terminal family."""

        result = self._calculator.calculate_current(current).result
        if result is None:
            raise ValueError("calculation result is stale")
        seed = propose_fixture_bottom_reinforcement(current)
        candidate = replace(
            seed,
            candidate_id=f"terminal-{reason}",
            proposal=replace(seed.proposal, bottom_bars=current.bottom.bars),
            rationale="Retain the verified current design.",
        )
        self.last_search_metrics = {
            "candidates_attempted": 0,
            "candidates_valid": 0,
            "declared_stage_ids": ("verify_terminal_state",),
            "completed_stage_ids": ("verify_terminal_state",),
        }
        return DesignBrainPreview(candidate, result, result, (), False, reason)

    @staticmethod
    def _has_sls(inputs: BeamInputs) -> bool:
        s = inputs.serviceability
        return any(abs(float(v or 0.0)) > 1e-12 for v in (s.moment_knm, s.shear_kn, s.permanent_udl_knm_per_m, s.imposed_udl_knm_per_m, s.equivalent_udl_knm_per_m))

    def _calculate_for_design_brain(self, inputs: BeamInputs) -> EngineeringResult | None:
        """Use a private provisional SLS proxy only for candidate ranking."""
        if self._has_sls(inputs) or not inputs.serviceability.use_uls_fallback:
            return self._calculator.calculate_current(inputs).result
        self.last_search_metrics["sls_source"] = "PROVISIONAL_ULS_RATIO_PROXY"
        self.last_search_metrics["sls_proxy_ratio"] = 0.60
        provisional = replace(
            inputs,
            serviceability=replace(
                inputs.serviceability,
                moment_knm=0.60 * float(inputs.actions.bending_moment_knm),
                shear_kn=0.60 * float(inputs.actions.shear_force_kn),
                use_uls_fallback=True,
            ),
        )
        return self._calculator.calculate_current(provisional).result

    def _evaluate(self, current: BeamInputs, candidate: Candidate, *, provisional: bool = False):
        """Evaluate and count every family candidate through one pipeline."""
        self.last_search_metrics["candidates_attempted"] = int(self.last_search_metrics.get("candidates_attempted", 0)) + 1
        calculate = self._calculate_for_design_brain if provisional else lambda inputs: self._calculator.calculate_current(inputs).result
        evaluation = evaluate_candidate(current, candidate, calculate)
        if evaluation.usable:
            self.last_search_metrics["candidates_valid"] = int(self.last_search_metrics.get("candidates_valid", 0)) + 1
        return evaluation

    def _rank_key(
        self,
        current: BeamInputs,
        candidate: Candidate,
        result: EngineeringResult,
        target_distance: float,
        edit_size: float,
    ) -> tuple:
        """Use the shared, safety-first ranking contract for every family."""
        return candidate_rank_key(
            current,
            candidate,
            result,
            target_distance,
            edit_size,
            family_contract=self._active_family_contract,
        )

    def preview(self, current: BeamInputs) -> DesignBrainPreview:
        outcome = BendingFailurePipeline(
            calculate=lambda inputs: self._calculator.calculate_current(inputs).result,
            evaluate=self._evaluate,
        ).preview(current)
        if outcome.metrics is not None:
            self.last_search_metrics = outcome.metrics
        return outcome.preview
    def preview_shear_only(self, current: BeamInputs) -> DesignBrainPreview:
        """Apply the V1 SHEAR_FAIL_GOVERNS order: spacing, legs, diameter, depth, width."""
        pipeline = ShearFailurePipeline(
            calculate=lambda inputs: self._calculator.calculate_current(inputs).result,
            evaluate=self._evaluate,
            rank_key=self._rank_key,
        )
        return pipeline.preview(current)

    def preview_combined_failure(self, current: BeamInputs) -> DesignBrainPreview:
        """Repair simultaneous bending and shear failure with one atomic candidate."""
        return CombinedFailurePipeline(
            calculate=lambda inputs: self._calculator.calculate_current(inputs).result,
            evaluate=self._evaluate,
            rank_key=self._rank_key,
        ).preview(current)
    def preview_bending_failure_shear_cleanup(self, current: BeamInputs) -> DesignBrainPreview:
        """Distinct mixed-family entry point.

        The ordered mixed ladder is contract-owned even while it reuses the
        established bending repair engine for its first stage.  Keeping a
        separate entry point prevents the mixed family silently collapsing
        back into the bending-only owner during later ladder changes.
        """
        return self.preview(current)

    def preview_shear_failure_bending_optimise(self, current: BeamInputs) -> DesignBrainPreview:
        """Distinct mixed-family entry point for shear repair plus bending cleanup."""
        return self.preview_shear_only(current)

    def preview_bending_overdesign(self, current: BeamInputs) -> DesignBrainPreview:
        """V1 bending-overdesign cleanup: reduce bars/diameter, nearest safe target."""
        outcome = BendingOverdesignPipeline(
            calculate=lambda inputs: self._calculator.calculate_current(inputs).result,
            evaluate=self._evaluate,
            rank_key=self._rank_key,
        ).preview(current)
        self.last_search_metrics = outcome.metrics
        return outcome.preview
    def preview_shear_overdesign(self, current: BeamInputs) -> DesignBrainPreview:
        """V1 shear-overdesign cleanup: spacing, diameter, legs, then removal."""
        return ShearOverdesignPipeline(
            calculate=lambda inputs: self._calculator.calculate_current(inputs).result,
            evaluate=self._evaluate,
            rank_key=self._rank_key,
        ).preview(current)
    def preview_geometry_detailing(self, current: BeamInputs) -> DesignBrainPreview:
        """Repair the V1 depth/width geometry constraint without partial edits."""
        before = self._calculator.calculate_current(current).result
        assert before is not None
        seed = propose_fixture_bottom_reinforcement(current)
        maximum_depth = 2.0 * current.width_mm
        if current.depth_mm <= maximum_depth:
            return DesignBrainPreview(seed, before, before, (), False, "geometry_already_compliant")
        proposal = replace(seed.proposal, depth_mm=max(200.0, maximum_depth))
        candidate = Candidate("geometry-detailing-depth-width", current.revision, current.content_hash, proposal, "Geometry/detailing repair: reduce depth to the V1 maximum 2:1 depth-to-width ratio.")
        evaluation = self._evaluate(current, candidate)
        outcome = evaluation.outcome
        if not evaluation.usable:
            return DesignBrainPreview(candidate, before, before, ("depth_mm",), False, "geometry_candidate_validation_failed")
        after = evaluation.result
        assert after is not None
        return DesignBrainPreview(candidate, before, after, ("depth_mm",), True, "geometry_ratio_repaired", 0.85, 1.0)

    def preview_serviceability(self, current: BeamInputs) -> DesignBrainPreview:
        """Repair crack control and deflection with fully recalculated candidates."""
        def calculate(inputs: BeamInputs) -> EngineeringResult:
            result = self._calculator.calculate_current(inputs).result
            if result is None:
                raise ValueError("calculation result is stale")
            return result

        return ServiceabilityCandidatePipeline(
            calculate=calculate,
            evaluate=self._evaluate,
            rank_key=self._rank_key,
        ).preview(current)

    def preview_combined_overdesign(self, current: BeamInputs) -> DesignBrainPreview:
        """Reduce both reinforcement families in one reviewable candidate."""
        def calculate(inputs: BeamInputs) -> EngineeringResult:
            result = self._calculator.calculate_current(inputs).result
            if result is None:
                raise ValueError("calculation result is stale")
            return result

        return CombinedOverdesignPipeline(
            calculate=calculate,
            evaluate=self._evaluate,
            rank_key=self._rank_key,
        ).preview(current)

    def apply(self, current: BeamInputs, preview: DesignBrainPreview) -> ApplyOutcome:
        return apply_candidate(current, preview.candidate)

    def apply_decision(self, current: BeamInputs, decision: "FamilyDecision") -> ApplyOutcome:
        """Apply only the exact authoritative candidate displayed to the user."""
        if not decision.apply_allowed or decision.candidate is None:
            return ApplyOutcome(False, "decision_does_not_allow_apply", current)
        if decision.candidate.source_revision != current.revision or decision.candidate.source_hash != current.content_hash:
            return ApplyOutcome(False, "stale_candidate", current)
        outcome = apply_candidate(current, decision.candidate)
        if not outcome.applied:
            return outcome
        recalculated = self._calculator.calculate_current(outcome.inputs).result
        displayed = decision.proposed_result
        if recalculated is None or displayed is None:
            return ApplyOutcome(False, "proposed_result_unavailable", current)
        if recalculated.source_hash != displayed.source_hash or recalculated.source_revision != displayed.source_revision:
            return ApplyOutcome(False, "displayed_proposal_mismatch", current)
        if not _complete_compliance(recalculated):
            return ApplyOutcome(False, "proposal_no_longer_compliant", current)
        return outcome
